import xgboost as xgb
import os

model_zip = "XGBoost_model_python_1598478696138_1.zip"
tmp_dir = "tmp"

os.system(f"unzip -o {model_zip} -d {tmp_dir}")


gbdt = xgb.Booster()
gbdt.load_model(f"./{tmp_dir}/boosterBytes")

fmap_in = open(f"./{tmp_dir}/feature_map", "r")
fmap_out = open(f"./{tmp_dir}/feature.map", "w")

for line in fmap_in:
    parts = line.split(" ")
    fmap_out.write('{0}\t{1}\tq\n'.format(parts[0], parts[1]))

fmap_in.close()
fmap_out.close()

gbdt.dump_model('xgb.dump', fmap=f"./{tmp_dir}/feature.map", with_stats=True)
# requires mono-complete
os.system("mono XgbFeatureInteractions.exe")
os.system(f"rm -rf {tmp_dir}")
os.system(f"rm xgb.dump")




